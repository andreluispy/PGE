# PGE
 Python Game Engine make with PyGame

 An easier alternative that automates the things you would do with PyGame

 2D Engine(SDL using PyGame)
 
 3D Engine(Coming Soon)

# Starting
 Install with pip in windows:
 `pip install --upgrade pge-engine`
 
 Install with pip3 in Linux Ubuntu:
 `pip3 install --upgrade pge-engine`

# View Docs
View Docs: [https://github.com/andreluispy/PGE/tree/main/docs](https://github.com/andreluispy/PGE/tree/main/docs)

# ChangeLog
1.0: Keyboard/Mouse/Circle/Rect/Sprite

2.0: Music Mixer/Detect colision/Class Color(get rgb of colors)/Code Simplification

Coming Soon: 3.0: 3D Engine(OpenGL)
